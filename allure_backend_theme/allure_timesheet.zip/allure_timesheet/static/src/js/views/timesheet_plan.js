odoo.define('allure_timesheet.ProjectPlan', function (require) {
    "use strict";

    var ProjectPlan = require('sale_timesheet.ProjectPlan');

    ProjectPlan.include({
        start: function () {
            var self = this;
            return $.when(this._super.apply(this, arguments)).then(function () {
                self.$searchview_buttons = self.searchview.$buttons;
                self.searchview.$buttons.addClass('ad_has_options')
            });
        },
    });

});
