# -*- coding: utf-8 -*-
# Part of Synconics. See LICENSE file for full copyright and licensing details.

{
    'name': 'Allure Backend Theme Timesheet',
    'category': "Themes/Backend",
    'version': '1.1',
    'license': 'OPL-1',
    'summary': 'Customized Backend Theme With Timesheet',
    'description': 'Customized Backend Theme With Timesheet',
    'author': 'Synconics Technologies Pvt. Ltd.',
    'depends': ['allure_backend_theme', 'sale_timesheet'],
    'website': 'www.synconics.com',
    'data': [
        'views/webclient_templates.xml',
    ],
    'installable': True,
    'auto_install': False,
    'bootstrap': True,
    'application': True,
}
